import os
import base64
from pathlib import Path
from typing import Optional
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

load_dotenv()
API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash").strip()
ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"

app = FastAPI(title="Fifty Alalami AI", version="0.1.0")
# Required for the Android WebView's local asset origin. Restrict origins and add auth before public launch.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization"],
)
app.mount("/static", StaticFiles(directory=str(STATIC)), name="static")

SYSTEM_INSTRUCTION = (
    "أنت فيفتي العالمي AI، مساعد ذكي يتحدث بالعربية المصرية أو باللغة التي يطلبها المستخدم. "
    "ساعد في البرمجة وشرح الأكواد وتصحيحها والبحث عن المعلومات. كن واضحًا وصريحًا بشأن عدم اليقين. "
    "عند تقديم معلومات حديثة، استخدم البحث إذا كانت أداة البحث متاحة وأشر إلى المصادر التي يعرضها النظام. "
    "في الأمن السيبراني، ركّز على التعلم والدفاع والتحليل واختبار الأنظمة التي يملكها المستخدم أو لديه تصريح بفحصها. "
    "لا تدّعِ أنك نفّذت كودًا أو بحثًا إن لم يحدث ذلك فعليًا. لا تشغّل كود المستخدم على الخادم."
)

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)
    history: list[dict] = Field(default_factory=list)
    use_search: bool = True
    image_data_url: Optional[str] = None

@app.get("/")
def index():
    return FileResponse(STATIC / "index.html")

@app.get("/manifest.json")
def manifest():
    return FileResponse(STATIC / "manifest.json", media_type="application/manifest+json")

@app.get("/sw.js")
def service_worker():
    return FileResponse(STATIC / "sw.js", media_type="application/javascript")

@app.get("/api/health")
def health():
    return {"ok": True, "model": MODEL, "key_configured": bool(API_KEY)}

@app.post("/api/chat")
async def chat(req: ChatRequest):
    if not API_KEY:
        raise HTTPException(
            status_code=503,
            detail="مفتاح Gemini غير مضبوط. انسخ .env.example إلى .env وأضف GEMINI_API_KEY."
        )

    contents = []
    # Accept only a short, sanitized conversation history.
    for item in req.history[-12:]:
        role = item.get("role")
        text = item.get("text")
        if role in ("user", "model") and isinstance(text, str) and text.strip():
            contents.append({"role": role, "parts": [{"text": text[:8000]}]})

    parts = [{"text": req.message}]
    if req.image_data_url:
        try:
            header, encoded = req.image_data_url.split(",", 1)
            mime = header.split(";")[0].replace("data:", "")
            if mime not in ("image/png", "image/jpeg", "image/webp"):
                raise ValueError("unsupported image type")
            raw = base64.b64decode(encoded, validate=True)
            if len(raw) > 5 * 1024 * 1024:
                raise ValueError("image too large")
            parts.append({"inline_data": {"mime_type": mime, "data": base64.b64encode(raw).decode("ascii")}})
        except Exception:
            raise HTTPException(status_code=400, detail="الصورة غير صالحة أو حجمها أكبر من 5 ميجابايت.")

    contents.append({"role": "user", "parts": parts})
    body = {
        "system_instruction": {"parts": [{"text": SYSTEM_INSTRUCTION}]},
        "contents": contents,
        "generationConfig": {"temperature": 0.5, "maxOutputTokens": 4096},
    }
    if req.use_search:
        body["tools"] = [{"google_search": {}}]

    url = f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent"
    try:
        async with httpx.AsyncClient(timeout=90) as client:
            response = await client.post(
                url,
                params={"key": API_KEY},
                json=body,
                headers={"Content-Type": "application/json"},
            )
        data = response.json()
        if response.status_code >= 400:
            message = data.get("error", {}).get("message", "تعذر الاتصال بخدمة الذكاء الاصطناعي.")
            raise HTTPException(status_code=response.status_code, detail=message[:500])
        candidates = data.get("candidates", [])
        if not candidates:
            raise HTTPException(status_code=502, detail="لم يرجع النموذج إجابة. جرّب صياغة أخرى.")
        response_parts = candidates[0].get("content", {}).get("parts", [])
        answer = "\n".join(p.get("text", "") for p in response_parts if p.get("text"))
        if not answer:
            answer = "وصل رد من النموذج لكن بدون نص قابل للعرض."
        sources = []
        for meta in candidates[0].get("groundingMetadata", {}).get("groundingChunks", []):
            web = meta.get("web", {})
            if web.get("uri"):
                sources.append({"title": web.get("title", web["uri"]), "url": web["uri"]})
        return {"answer": answer, "sources": sources, "model": MODEL}
    except HTTPException:
        raise
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="انتهت مهلة الاتصال. جرّب مرة أخرى.")
    except Exception:
        raise HTTPException(status_code=502, detail="حدث خطأ أثناء الاتصال بخدمة الذكاء الاصطناعي.")
